﻿namespace Domain;

public enum Role
{
    Doctor,
    Nurse
}